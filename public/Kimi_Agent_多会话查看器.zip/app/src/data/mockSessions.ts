import type { AgentId, Session } from '@/lib/types';
import { AGENTS } from '@/lib/types';

// ---------------------------------------------------------------------------
// 12 个演示会话（每个 Agent 2 个），内容为中英混合的真实编码对话，
// 包含工具调用（⚙ Read/Edit/Bash）、代码块与 diff 块。
// ---------------------------------------------------------------------------

export const mockSessions: Session[] = [
  // ============================ Claude Code ============================
  {
    id: 'sess-claude-1',
    agentId: 'claude',
    title: '修复 JWT 鉴权中间件的过期判断',
    filePath: '~/.claude/projects/session-a91f3c.jsonl',
    cwd: '~/projects/shop-api',
    date: '2025-07-28',
    turnCount: 12,
    tokenCount: 18420,
    messages: [
      {
        id: 'c1-m1', role: 'user', kind: 'text', timestamp: '14:02', tokenEst: 96,
        content: '线上偶发 401，但 token 明明还没过期。怀疑是 `authMiddleware` 里的过期判断有问题，帮我看一下 `src/middleware/auth.ts`。',
      },
      {
        id: 'c1-m2', role: 'assistant', kind: 'tool', timestamp: '14:02', tokenEst: 12,
        toolName: 'Read',
        content: '⚙ Read(src/middleware/auth.ts) · 68 lines',
      },
      {
        id: 'c1-m3', role: 'assistant', kind: 'text', timestamp: '14:03', tokenEst: 210,
        content: '找到问题了。第 34 行用 `exp * 1000 < Date.now()` 判断过期，但上游签发方在部分集群用的是**毫秒时间戳**，导致乘以 1000 后判断提前了几千年失效。\n\n另外 leeway 没配置，时钟偏移也会造成抖动。我建议改成自适应判断。',
      },
      {
        id: 'c1-m4', role: 'assistant', kind: 'diff', timestamp: '14:03', tokenEst: 340,
        content: '--- a/src/middleware/auth.ts\n+++ b/src/middleware/auth.ts\n@@ -31,8 +31,12 @@\n export function isExpired(payload: JwtPayload): boolean {\n-  return payload.exp * 1000 < Date.now();\n+  // exp 可能是秒或毫秒时间戳，自适应判断\n+  const expMs = payload.exp < 1e12 ? payload.exp * 1000 : payload.exp;\n+  const leewayMs = (config.jwtLeeway ?? 30) * 1000;\n+  return expMs + leewayMs < Date.now();\n }\n',
      },
      {
        id: 'c1-m5', role: 'user', kind: 'text', timestamp: '14:05', tokenEst: 54,
        content: '可以，顺手补个单测覆盖秒/毫秒两种情况。',
      },
      {
        id: 'c1-m6', role: 'assistant', kind: 'code', timestamp: '14:06', tokenEst: 420,
        language: 'ts',
        content: "import { isExpired } from '@/middleware/auth';\n\ndescribe('isExpired', () => {\n  it('handles seconds-based exp', () => {\n    const payload = { exp: Math.floor(Date.now() / 1000) - 60 };\n    expect(isExpired(payload)).toBe(true);\n  });\n\n  it('handles millis-based exp', () => {\n    const payload = { exp: Date.now() + 60_000 };\n    expect(isExpired(payload)).toBe(false);\n  });\n\n  it('respects leeway window', () => {\n    const payload = { exp: Date.now() - 10_000 }; // 刚过 10s，leeway 30s\n    expect(isExpired(payload)).toBe(false);\n  });\n});",
      },
      {
        id: 'c1-m7', role: 'assistant', kind: 'tool', timestamp: '14:06', tokenEst: 18,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm test auth) · 24 passed · 1.8s',
      },
      {
        id: 'c1-m8', role: 'assistant', kind: 'text', timestamp: '14:07', tokenEst: 130,
        content: '全部通过 ✅。改动点总结：\n\n1. `isExpired` 兼容秒/毫秒两种 `exp`\n2. 新增 `jwtLeeway` 配置（默认 30s）\n3. 单测 3 条覆盖了两种时间戳和 leeway 窗口\n\n建议发布前先灰度 5% 观察一小时 401 率。',
      },
      {
        id: 'c1-m9', role: 'user', kind: 'text', timestamp: '14:08', tokenEst: 22,
        content: '好，先合到 develop，明天灰度。',
      },
    ],
  },
  {
    id: 'sess-claude-2',
    agentId: 'claude',
    title: '为 GraphQL API 添加游标分页与查询缓存',
    filePath: '~/.claude/projects/session-b77e21.jsonl',
    cwd: '~/projects/order-service',
    date: '2025-07-25',
    turnCount: 14,
    tokenCount: 26110,
    messages: [
      {
        id: 'c2-m1', role: 'user', kind: 'text', timestamp: '10:12', tokenEst: 120,
        content: '订单列表一次性查全量，数据量上来之后接口 3s+。帮忙改成 cursor-based 分页，并给热点查询加一层缓存。相关 resolver 在 `src/graphql/order.resolver.ts`。',
      },
      {
        id: 'c2-m2', role: 'assistant', kind: 'tool', timestamp: '10:12', tokenEst: 14,
        toolName: 'Read',
        content: '⚙ Read(src/graphql/order.resolver.ts) · 142 lines',
      },
      {
        id: 'c2-m3', role: 'assistant', kind: 'tool', timestamp: '10:13', tokenEst: 16,
        toolName: 'Read',
        content: '⚙ Read(src/graphql/schema.graphql) · 96 lines',
      },
      {
        id: 'c2-m4', role: 'assistant', kind: 'text', timestamp: '10:14', tokenEst: 260,
        content: '方案：\n\n- **分页**：采用 Relay 风格的 `first/after` 游标分页，cursor 用 base64(`order:${id}`) 编码，配合 `created_at + id` 联合索引避免深翻页。\n- **缓存**：对 `orders(first: 20)` 这类首屏查询走 Redis，key 含参数哈希，TTL 60s，写操作后按 tag 失效。',
      },
      {
        id: 'c2-m5', role: 'assistant', kind: 'code', timestamp: '10:15', tokenEst: 610,
        language: 'ts',
        content: "export const orderResolver = {\n  Query: {\n    orders: async (_: unknown, args: OrdersArgs, ctx: Context) => {\n      const cacheKey = `orders:${hash(args)}`;\n      const cached = await ctx.redis.get(cacheKey);\n      if (cached) return JSON.parse(cached);\n\n      const after = args.after ? decodeCursor(args.after) : null;\n      const rows = await ctx.db.order.findMany({\n        take: args.first + 1,\n        where: after ? { id: { gt: after.id } } : {},\n        orderBy: [{ createdAt: 'desc' }, { id: 'asc' }],\n      });\n\n      const hasNextPage = rows.length > args.first;\n      const nodes = rows.slice(0, args.first);\n      const result = {\n        edges: nodes.map((n) => ({ node: n, cursor: encodeCursor(n.id) })),\n        pageInfo: { hasNextPage, endCursor: encodeCursor(nodes.at(-1)?.id) },\n      };\n      if (args.first === 20) await ctx.redis.set(cacheKey, JSON.stringify(result), 'EX', 60);\n      return result;\n    },\n  },\n};",
      },
      {
        id: 'c2-m6', role: 'user', kind: 'text', timestamp: '10:18', tokenEst: 48,
        content: 'cursor 解码失败会抛什么？前端传脏数据会不会把接口打 500？',
      },
      {
        id: 'c2-m7', role: 'assistant', kind: 'diff', timestamp: '10:19', tokenEst: 290,
        content: "--- a/src/graphql/order.resolver.ts\n+++ b/src/graphql/order.resolver.ts\n@@ -5,7 +5,11 @@\n-      const after = args.after ? decodeCursor(args.after) : null;\n+      let after: Cursor | null = null;\n+      try {\n+        after = args.after ? decodeCursor(args.after) : null;\n+      } catch {\n+        throw new UserInputError('invalid cursor', { cursor: args.after });\n+      }\n",
      },
      {
        id: 'c2-m8', role: 'assistant', kind: 'text', timestamp: '10:19', tokenEst: 96,
        content: '好问题，已补：脏 cursor 统一转成 `UserInputError`（400），不再穿透成 500。',
      },
      {
        id: 'c2-m9', role: 'assistant', kind: 'tool', timestamp: '10:20', tokenEst: 22,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm test graphql/order) · 18 passed · 2.4s',
      },
      {
        id: 'c2-m10', role: 'assistant', kind: 'text', timestamp: '10:21', tokenEst: 74,
        content: '测试全绿。压测了一下：首屏 P95 从 3.2s 降到 180ms，缓存命中率约 78%。可以提 MR 了。',
      },
    ],
  },

  // ============================ Grok Build ============================
  {
    id: 'sess-grok-1',
    agentId: 'grok',
    title: '构建实时日志流 Dashboard 组件',
    filePath: '~/.grok/sessions/logstream-dash.session.md',
    cwd: '~/work/logpulse-frontend',
    date: '2025-07-27',
    turnCount: 10,
    tokenCount: 15240,
    messages: [
      {
        id: 'g1-m1', role: 'user', kind: 'text', timestamp: '09:31', tokenEst: 88,
        content: 'I need a real-time log streaming dashboard component. WebSocket 推送，要求每秒上千条也不卡 UI。用 React 实现。',
      },
      {
        id: 'g1-m2', role: 'assistant', kind: 'text', timestamp: '09:32', tokenEst: 240,
        content: "Architecture plan:\n\n1. **Buffer layer** — WS messages land in a ring buffer (no React state), flushed at 30fps via rAF\n2. **Virtualized list** — only render the ~40 visible rows\n3. **Pause on scroll** — 用户上翻时冻结自动滚动，到底部再恢复\n\nHigh-frequency state stays in refs, never in `useState`.",
      },
      {
        id: 'g1-m3', role: 'assistant', kind: 'code', timestamp: '09:33', tokenEst: 560,
        language: 'tsx',
        content: "export function LogStream({ url }: { url: string }) {\n  const buffer = useRef<LogLine[]>([]);\n  const [, force] = useReducer((x: number) => x + 1, 0);\n  const listRef = useRef<HTMLDivElement>(null);\n  const paused = useRef(false);\n\n  useEffect(() => {\n    const ws = new WebSocket(url);\n    ws.onmessage = (e) => {\n      buffer.current.push(JSON.parse(e.data));\n      if (buffer.current.length > 5000) buffer.current.splice(0, 1000);\n    };\n    let raf = 0;\n    const tick = () => { force(); raf = requestAnimationFrame(tick); };\n    raf = requestAnimationFrame(tick);\n    return () => { ws.close(); cancelAnimationFrame(raf); };\n  }, [url]);\n\n  // 渲染层只做虚拟化截取\n  return <VirtualList ref={listRef} items={buffer.current} rowHeight={22} />;\n}",
      },
      {
        id: 'g1-m4', role: 'user', kind: 'text', timestamp: '09:36', tokenEst: 60,
        content: '30fps force update every frame — 没有新消息的时候也在重渲染吧？',
      },
      {
        id: 'g1-m5', role: 'assistant', kind: 'text', timestamp: '09:37', tokenEst: 150,
        content: '对，浪费。改成「脏标记」：只有 buffer 长度变化才触发渲染，空闲时 rAF 零成本。',
      },
      {
        id: 'g1-m6', role: 'assistant', kind: 'diff', timestamp: '09:37', tokenEst: 310,
        content: "--- a/src/components/LogStream.tsx\n+++ b/src/components/LogStream.tsx\n@@ -7,10 +7,13 @@\n     const ws = new WebSocket(url);\n+    let dirty = false;\n     ws.onmessage = (e) => {\n       buffer.current.push(JSON.parse(e.data));\n+      dirty = true;\n       if (buffer.current.length > 5000) buffer.current.splice(0, 1000);\n     };\n     let raf = 0;\n-    const tick = () => { force(); raf = requestAnimationFrame(tick); };\n+    const tick = () => {\n+      if (dirty) { force(); dirty = false; }\n+      raf = requestAnimationFrame(tick);\n+    };\n",
      },
      {
        id: 'g1-m7', role: 'assistant', kind: 'tool', timestamp: '09:38', tokenEst: 20,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm bench:logstream) · 1200 msg/s · CPU 8%',
      },
      {
        id: 'g1-m8', role: 'assistant', kind: 'text', timestamp: '09:39', tokenEst: 82,
        content: 'Benchmark: 1200 条/秒持续 60s，主线程占用 8%，掉帧 0。组件已就绪，还差筛选和关键字高亮，要接着做吗？',
      },
    ],
  },
  {
    id: 'sess-grok-2',
    agentId: 'grok',
    title: '优化 Webpack 打包体积与冷启动',
    filePath: '~/.grok/sessions/bundle-diet.session.md',
    cwd: '~/work/admin-console',
    date: '2025-07-22',
    turnCount: 8,
    tokenCount: 11860,
    messages: [
      {
        id: 'g2-m1', role: 'user', kind: 'text', timestamp: '16:44', tokenEst: 74,
        content: '生产包 4.8MB，首屏太慢。帮我分析下 webpack 配置，给出瘦身方案。',
      },
      {
        id: 'g2-m2', role: 'assistant', kind: 'tool', timestamp: '16:45', tokenEst: 15,
        toolName: 'Read',
        content: '⚙ Read(webpack.config.js) · 112 lines',
      },
      {
        id: 'g2-m3', role: 'assistant', kind: 'tool', timestamp: '16:45', tokenEst: 24,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm build --stats && npx webpack-bundle-analyzer) · 4.81MB',
      },
      {
        id: 'g2-m4', role: 'assistant', kind: 'text', timestamp: '16:46', tokenEst: 320,
        content: 'Analyzer 报告三个大头：\n\n| 模块 | 体积 | 处理 |\n|---|---|---|\n| `lodash`（全量引入）| 1.2MB | 改 `lodash-es` + 按需 import |\n| `moment` + locale | 620KB | 换 `dayjs`（12KB） |\n| `monaco-editor` | 1.9MB | 路由级 `import()` 懒加载 |\n\n再开 `splitChunks` 的 vendor 缓存组和 `brotli` 压缩。',
      },
      {
        id: 'g2-m5', role: 'assistant', kind: 'code', timestamp: '16:47', tokenEst: 380,
        language: 'js',
        content: "module.exports = {\n  optimization: {\n    splitChunks: {\n      cacheGroups: {\n        vendor: {\n          test: /[\\\\/]node_modules[\\\\/]/,\n          name: 'vendors',\n          chunks: 'all',\n        },\n      },\n    },\n  },\n  plugins: [\n    new CompressionPlugin({ algorithm: 'brotliCompress', filename: '[path][base].br' }),\n  ],\n};\n\n// 编辑器页懒加载\nconst EditorPage = lazy(() => import('./pages/EditorPage'));",
      },
      {
        id: 'g2-m6', role: 'user', kind: 'text', timestamp: '16:52', tokenEst: 40,
        content: 'moment 替换涉及多少文件？有没有 codemod？',
      },
      {
        id: 'g2-m7', role: 'assistant', kind: 'tool', timestamp: '16:53', tokenEst: 26,
        toolName: 'Bash',
        content: "⚙ Bash(npx jscodeshift -t codemods/moment-to-dayjs.js src/) · 31 files",
      },
      {
        id: 'g2-m8', role: 'assistant', kind: 'text', timestamp: '16:54', tokenEst: 90,
        content: 'Codemod 跑了 31 个文件，全部自动迁移成功。重新构建：**4.81MB → 1.42MB**（-70%），brotli 后 gzip 等价 380KB。Lighthouse 冷启动 FCP 3.9s → 1.4s。',
      },
    ],
  },
];

// ---------------------------------------------------------------------------
// 第二批：OpenCode / Codex CLI
// ---------------------------------------------------------------------------

mockSessions.push(
  // ============================ OpenCode ============================
  {
    id: 'sess-opencode-1',
    agentId: 'opencode',
    title: '重构文件上传模块支持断点续传',
    filePath: '~/.local/share/opencode/session_9f2ac1.json',
    cwd: '/home/dev/projects/uplink',
    date: '2025-07-26',
    turnCount: 11,
    tokenCount: 19730,
    messages: [
      {
        id: 'o1-m1', role: 'user', kind: 'text', timestamp: '11:05', tokenEst: 102,
        content: '大文件上传经常失败重来，用户体验很差。把 `src/upload/uploader.ts` 重构成分片上传 + 断点续传，后端已有 `/upload/chunk` 和 `/upload/merge` 接口。',
      },
      {
        id: 'o1-m2', role: 'assistant', kind: 'tool', timestamp: '11:05', tokenEst: 13,
        toolName: 'Read',
        content: '⚙ Read(src/upload/uploader.ts) · 89 lines',
      },
      {
        id: 'o1-m3', role: 'assistant', kind: 'text', timestamp: '11:06', tokenEst: 230,
        content: '设计：\n\n- 文件按 **4MB** 切片，先算 `xxhash` 作为 `fileId` 秒传\n- 每片带 `chunkIndex` 上传，失败自动重试 3 次（指数退避）\n- 已成功的分片写入 `localStorage`，刷新页面后可续传\n- 全部完成后调 `/upload/merge` 合并',
      },
      {
        id: 'o1-m4', role: 'assistant', kind: 'code', timestamp: '11:07', tokenEst: 640,
        language: 'ts',
        content: "const CHUNK_SIZE = 4 * 1024 * 1024;\n\nexport async function uploadFile(file: File, onProgress?: (p: number) => void) {\n  const fileId = await xxhashFile(file);\n  const done = loadDoneChunks(fileId); // localStorage 恢复\n  const total = Math.ceil(file.size / CHUNK_SIZE);\n\n  for (let i = 0; i < total; i++) {\n    if (done.has(i)) continue;\n    const blob = file.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);\n    await retry(\n      () => postChunk(fileId, i, blob),\n      { times: 3, backoff: (n) => 2 ** n * 500 },\n    );\n    done.add(i);\n    saveDoneChunks(fileId, done);\n    onProgress?.(done.size / total);\n  }\n  const res = await postMerge(fileId, total);\n  clearDoneChunks(fileId);\n  return res.url;\n}",
      },
      {
        id: 'o1-m5', role: 'user', kind: 'text', timestamp: '11:10', tokenEst: 56,
        content: '并发呢？串行上传 2GB 文件要等到天荒地老。',
      },
      {
        id: 'o1-m6', role: 'assistant', kind: 'text', timestamp: '11:11', tokenEst: 120,
        content: '有道理。加个并发池，4 路并行，同时避免浏览器连接数打满：',
      },
      {
        id: 'o1-m7', role: 'assistant', kind: 'diff', timestamp: '11:11', tokenEst: 330,
        content: "--- a/src/upload/uploader.ts\n+++ b/src/upload/uploader.ts\n@@ -10,9 +10,13 @@\n-  for (let i = 0; i < total; i++) {\n-    if (done.has(i)) continue;\n-    const blob = file.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);\n-    await retry(() => postChunk(fileId, i, blob), { times: 3, backoff });\n-    done.add(i);\n-    saveDoneChunks(fileId, done);\n-    onProgress?.(done.size / total);\n-  }\n+  const pending = range(total).filter((i) => !done.has(i));\n+  await pool(pending, 4, async (i) => {\n+    const blob = file.slice(i * CHUNK_SIZE, (i + 1) * CHUNK_SIZE);\n+    await retry(() => postChunk(fileId, i, blob), { times: 3, backoff });\n+    done.add(i);\n+    saveDoneChunks(fileId, done);\n+    onProgress?.(done.size / total);\n+  });\n",
      },
      {
        id: 'o1-m8', role: 'assistant', kind: 'tool', timestamp: '11:12', tokenEst: 19,
        toolName: 'Edit',
        content: '⚙ Edit(src/upload/uploader.ts) · +28 −9 lines',
      },
      {
        id: 'o1-m9', role: 'assistant', kind: 'tool', timestamp: '11:13', tokenEst: 22,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm test upload) · 15 passed · 3.1s',
      },
      {
        id: 'o1-m10', role: 'assistant', kind: 'text', timestamp: '11:14', tokenEst: 68,
        content: '完成 ✅。实测 1.8GB 视频文件：串行 6分40秒 → 4 并发 1分52秒；中途杀进程再打开页面，从 61% 继续。',
      },
    ],
  },
  {
    id: 'sess-opencode-2',
    agentId: 'opencode',
    title: '为 CLI 添加 --watch 增量编译模式',
    filePath: '~/.local/share/opencode/session_41de07.json',
    cwd: '~/oss/fmt-cli',
    date: '2025-07-21',
    turnCount: 8,
    tokenCount: 9850,
    messages: [
      {
        id: 'o2-m1', role: 'user', kind: 'text', timestamp: '15:20', tokenEst: 78,
        content: '给 build 命令加 `--watch` 模式：监听 src 目录，文件变更后只做增量编译，别整包重来。',
      },
      {
        id: 'o2-m2', role: 'assistant', kind: 'tool', timestamp: '15:20', tokenEst: 14,
        toolName: 'Read',
        content: '⚙ Read(src/cli/build.ts) · 74 lines',
      },
      {
        id: 'o2-m3', role: 'assistant', kind: 'code', timestamp: '15:21', tokenEst: 430,
        language: 'ts',
        content: "import chokidar from 'chokidar';\n\nexport async function build(opts: BuildOptions) {\n  await compileAll();\n  if (!opts.watch) return;\n\n  const graph = new DepGraph(); // 编译期收集\n  const watcher = chokidar.watch('src/**/*.{ts,tsx}', { ignoreInitial: true });\n\n  watcher.on('change', async (file) => {\n    const affected = graph.dependentsOf(file);\n    const t0 = performance.now();\n    await compileModules([file, ...affected]);\n    console.log(`✓ rebuilt ${affected.size + 1} modules in ${(performance.now() - t0).toFixed(0)}ms`);\n  });\n}",
      },
      {
        id: 'o2-m4', role: 'user', kind: 'text', timestamp: '15:24', tokenEst: 44,
        content: '连续快速保存会触发多次编译吧，加个防抖。',
      },
      {
        id: 'o2-m5', role: 'assistant', kind: 'diff', timestamp: '15:25', tokenEst: 240,
        content: "--- a/src/cli/build.ts\n+++ b/src/cli/build.ts\n@@ -8,6 +8,9 @@\n-  watcher.on('change', async (file) => {\n-    const affected = graph.dependentsOf(file);\n+  const schedule = debounce(async (file: string) => {\n+    const affected = graph.dependentsOf(file);\n+    ...\n+  }, 100);\n+  watcher.on('change', schedule);\n",
      },
      {
        id: 'o2-m6', role: 'assistant', kind: 'tool', timestamp: '15:26', tokenEst: 21,
        toolName: 'Bash',
        content: '⚙ Bash(node dist/cli.js build --watch) · 增量 62ms',
      },
      {
        id: 'o2-m7', role: 'assistant', kind: 'text', timestamp: '15:27', tokenEst: 72,
        content: '验证：单文件保存增量编译 62ms（全量 8.3s），防抖生效。顺手把 `--watch` 写进了 README 的 CLI 章节。',
      },
    ],
  },

  // ============================ Codex CLI ============================
  {
    id: 'sess-codex-1',
    agentId: 'codex',
    title: '实现带 TTL 的 LRU 缓存淘汰策略',
    filePath: '~/.codex/sessions/rollout-2025-07-24T13-40.jsonl',
    cwd: '~/projects/cache-kit',
    date: '2025-07-24',
    turnCount: 9,
    tokenCount: 13420,
    messages: [
      {
        id: 'c1x-m1', role: 'user', kind: 'text', timestamp: '13:41', tokenEst: 84,
        content: '实现一个 LRU cache：容量上限 1000，每条记录支持独立 TTL，get/put 都要 O(1)。放在 `src/cache/lru.ts`，附单测。',
      },
      {
        id: 'c1x-m2', role: 'assistant', kind: 'code', timestamp: '13:42', tokenEst: 520,
        language: 'ts',
        content: "type Node<V> = { key: string; value: V; expireAt: number; prev?: Node<V>; next?: Node<V> };\n\nexport class LruCache<V> {\n  private map = new Map<string, Node<V>>();\n  private head?: Node<V>;\n  private tail?: Node<V>;\n\n  constructor(private capacity = 1000) {}\n\n  get(key: string): V | undefined {\n    const node = this.map.get(key);\n    if (!node) return undefined;\n    if (Date.now() > node.expireAt) { this.remove(node); return undefined; }\n    this.touch(node); // 移到链表头\n    return node.value;\n  }\n\n  put(key: string, value: V, ttlMs = 60_000): void {\n    this.get(key); // 命中则刷新位置\n    if (this.map.has(key)) this.remove(this.map.get(key)!);\n    const node: Node<V> = { key, value, expireAt: Date.now() + ttlMs };\n    this.unshift(node);\n    this.map.set(key, node);\n    if (this.map.size > this.capacity) this.evict();\n  }\n\n  private evict() {\n    if (this.tail) { this.map.delete(this.tail.key); this.remove(this.tail); }\n  }\n  // touch / unshift / remove 均为 O(1) 链表操作\n}",
      },
      {
        id: 'c1x-m3', role: 'user', kind: 'text', timestamp: '13:45', tokenEst: 58,
        content: '`put` 里 `this.get(key)` 有副作用：会刷新 TTL 命中判断并改链表，语义不干净。拆一下。',
      },
      {
        id: 'c1x-m4', role: 'assistant', kind: 'diff', timestamp: '13:46', tokenEst: 260,
        content: "--- a/src/cache/lru.ts\n+++ b/src/cache/lru.ts\n@@ -18,8 +18,10 @@\n   put(key: string, value: V, ttlMs = 60_000): void {\n-    this.get(key); // 命中则刷新位置\n-    if (this.map.has(key)) this.remove(this.map.get(key)!);\n+    const existing = this.map.get(key);\n+    if (existing) this.remove(existing); // 直接操作链表，不走 get\n     const node: Node<V> = { key, value, expireAt: Date.now() + ttlMs };\n",
      },
      {
        id: 'c1x-m5', role: 'assistant', kind: 'code', timestamp: '13:47', tokenEst: 350,
        language: 'ts',
        content: "describe('LruCache', () => {\n  it('evicts least recently used beyond capacity', () => {\n    const c = new LruCache<number>(2);\n    c.put('a', 1); c.put('b', 2); c.get('a'); c.put('c', 3);\n    expect(c.get('b')).toBeUndefined();\n    expect(c.get('a')).toBe(1);\n  });\n\n  it('expires entries after ttl', async () => {\n    const c = new LruCache<number>();\n    c.put('x', 42, 20);\n    await sleep(30);\n    expect(c.get('x')).toBeUndefined();\n  });\n});",
      },
      {
        id: 'c1x-m6', role: 'assistant', kind: 'tool', timestamp: '13:48', tokenEst: 19,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm test cache) · 9 passed · 0.9s',
      },
      {
        id: 'c1x-m7', role: 'assistant', kind: 'text', timestamp: '13:49', tokenEst: 64,
        content: 'Done. 复杂度：get/put/evict 全部 O(1)；TTL 惰性过期（访问时判断），无后台定时器，避免 Node 进程挂住不退。',
      },
    ],
  },
  {
    id: 'sess-codex-2',
    agentId: 'codex',
    title: '数据库迁移脚本与慢查询索引优化',
    filePath: '~/.codex/sessions/rollout-2025-07-20T09-15.jsonl',
    cwd: '~/projects/shop-api',
    date: '2025-07-20',
    turnCount: 7,
    tokenCount: 10210,
    messages: [
      {
        id: 'c2x-m1', role: 'user', kind: 'text', timestamp: '09:16', tokenEst: 90,
        content: '`orders` 表 800 万行，按用户 + 状态 + 时间筛选的查询要 4 秒。写个迁移脚本加合适的索引，注意别锁表。',
      },
      {
        id: 'c2x-m2', role: 'assistant', kind: 'tool', timestamp: '09:16', tokenEst: 17,
        toolName: 'Bash',
        content: "⚙ Bash(EXPLAIN ANALYZE SELECT ... ) · Seq Scan · 4182ms",
      },
      {
        id: 'c2x-m3', role: 'assistant', kind: 'text', timestamp: '09:17', tokenEst: 190,
        content: '执行计划是全表 Seq Scan。复合索引列顺序按**等值在前、范围在后**：`(user_id, status, created_at DESC)`。\n\n关键：用 `CONCURRENTLY` 在线建索引，不拿 `ACCESS EXCLUSIVE` 锁，迁移期间读写不阻塞。',
      },
      {
        id: 'c2x-m4', role: 'assistant', kind: 'code', timestamp: '09:18', tokenEst: 280,
        language: 'sql',
        content: "-- migrations/20250720_add_orders_idx.sql\n-- 注意：CONCURRENTLY 不能在事务块内执行\nCREATE INDEX CONCURRENTLY IF NOT EXISTS idx_orders_user_status_created\n  ON orders (user_id, status, created_at DESC);\n\n-- 覆盖常用 select 列，走 index-only scan\nCREATE INDEX CONCURRENTLY IF NOT EXISTS idx_orders_covering\n  ON orders (user_id, status) INCLUDE (id, amount, created_at);",
      },
      {
        id: 'c2x-m5', role: 'assistant', kind: 'tool', timestamp: '09:22', tokenEst: 18,
        toolName: 'Bash',
        content: '⚙ Bash(psql -f migrations/20250720_add_orders_idx.sql) · 3m12s',
      },
      {
        id: 'c2x-m6', role: 'assistant', kind: 'tool', timestamp: '09:23', tokenEst: 17,
        toolName: 'Bash',
        content: '⚙ Bash(EXPLAIN ANALYZE SELECT ...) · Index Only Scan · 11ms',
      },
      {
        id: 'c2x-m7', role: 'assistant', kind: 'text', timestamp: '09:24', tokenEst: 70,
        content: '索引生效：**4182ms → 11ms**（-99.7%），走 Index Only Scan。迁移期间零锁表告警。记得给 `down` 迁移补 `DROP INDEX CONCURRENTLY`。',
      },
    ],
  },
);

// ---------------------------------------------------------------------------
// 第三批：Cursor / Aider + 导出辅助
// ---------------------------------------------------------------------------

mockSessions.push(
  // ============================ Cursor ============================
  {
    id: 'sess-cursor-1',
    agentId: 'cursor',
    title: '编辑器内联补全 UI 与防抖调优',
    filePath: '~/Library/Application Support/Cursor/chats/inline-cmp.chat.md',
    cwd: '~/ide/cursor-fork',
    date: '2025-07-27',
    turnCount: 8,
    tokenCount: 12680,
    messages: [
      {
        id: 'cu1-m1', role: 'user', kind: 'text', timestamp: '17:12', tokenEst: 80,
        content: '内联补全的 ghost text 出现时整行会抖动，而且打字快的时候请求太频繁。看看 `InlineCompletion.tsx` 怎么优化。',
      },
      {
        id: 'cu1-m2', role: 'assistant', kind: 'tool', timestamp: '17:12', tokenEst: 13,
        toolName: 'Read',
        content: '⚙ Read(src/editor/InlineCompletion.tsx) · 118 lines',
      },
      {
        id: 'cu1-m3', role: 'assistant', kind: 'text', timestamp: '17:13', tokenEst: 200,
        content: '两个问题：\n\n1. **抖动**：ghost text 用了 `inline-block` 占位撑开布局。应改为 `position: absolute` 覆盖渲染，不影响文档流。\n2. **请求风暴**：每次 keystroke 直接发请求。改为 150ms 防抖 + `AbortController` 取消上一次未完成请求。',
      },
      {
        id: 'cu1-m4', role: 'assistant', kind: 'diff', timestamp: '17:14', tokenEst: 300,
        content: "--- a/src/editor/InlineCompletion.tsx\n+++ b/src/editor/InlineCompletion.tsx\n@@ -22,7 +22,9 @@\n-  useEffect(() => {\n-    fetchCompletion(prefix).then(setGhost);\n-  }, [prefix]);\n+  useEffect(() => {\n+    const ctrl = new AbortController();\n+    const t = setTimeout(() => {\n+      fetchCompletion(prefix, { signal: ctrl.signal }).then(setGhost).catch(() => {});\n+    }, 150);\n+    return () => { clearTimeout(t); ctrl.abort(); };\n+  }, [prefix]);\n",
      },
      {
        id: 'cu1-m5', role: 'assistant', kind: 'code', timestamp: '17:15', tokenEst: 180,
        language: 'css',
        content: ".ghost-text {\n  position: absolute;\n  pointer-events: none;\n  color: var(--text-muted);\n  white-space: pre;\n  /* 不占据文档流，消除行抖动 */\n}",
      },
      {
        id: 'cu1-m6', role: 'user', kind: 'text', timestamp: '17:18', tokenEst: 34,
        content: 'Tab 接受补全的快捷键冲突处理了吗？',
      },
      {
        id: 'cu1-m7', role: 'assistant', kind: 'text', timestamp: '17:19', tokenEst: 120,
        content: '处理了：补全可见时 Tab 优先级最高并 `preventDefault`；不可见时透传给缩进逻辑。Esc 关闭补全，Alt+] 逐词接受。',
      },
      {
        id: 'cu1-m8', role: 'assistant', kind: 'tool', timestamp: '17:20', tokenEst: 19,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm test editor) · 27 passed · 1.6s',
      },
    ],
  },
  {
    id: 'sess-cursor-2',
    agentId: 'cursor',
    title: '重构设置面板为 zustand 分片状态',
    filePath: '~/Library/Application Support/Cursor/chats/settings-store.chat.md',
    cwd: '~/ide/cursor-fork',
    date: '2025-07-23',
    turnCount: 7,
    tokenCount: 8910,
    messages: [
      {
        id: 'cu2-m1', role: 'user', kind: 'text', timestamp: '14:50', tokenEst: 72,
        content: '设置面板现在 props drilling 三层，加一个选项要改 5 个文件。重构成 zustand，按域分 slice。',
      },
      {
        id: 'cu2-m2', role: 'assistant', kind: 'tool', timestamp: '14:50', tokenEst: 15,
        toolName: 'Read',
        content: '⚙ Read(src/settings/SettingsPanel.tsx) · 203 lines',
      },
      {
        id: 'cu2-m3', role: 'assistant', kind: 'code', timestamp: '14:52', tokenEst: 410,
        language: 'ts',
        content: "import { create } from 'zustand';\nimport { persist } from 'zustand/middleware';\n\ninterface EditorSlice {\n  fontSize: number;\n  tabSize: number;\n  setFontSize: (n: number) => void;\n}\ninterface ThemeSlice {\n  theme: 'dark' | 'light';\n  accent: string;\n  setTheme: (t: 'dark' | 'light') => void;\n}\n\nexport const useSettings = create<EditorSlice & ThemeSlice>()(\n  persist(\n    (set) => ({\n      fontSize: 14,\n      tabSize: 2,\n      setFontSize: (fontSize) => set({ fontSize }),\n      theme: 'dark',\n      accent: '#C6F63D',\n      setTheme: (theme) => set({ theme }),\n    }),\n    { name: 'app-settings' },\n  ),\n);",
      },
      {
        id: 'cu2-m4', role: 'user', kind: 'text', timestamp: '14:56', tokenEst: 40,
        content: '组件里怎么避免整个 store 订阅导致的无效重渲染？',
      },
      {
        id: 'cu2-m5', role: 'assistant', kind: 'text', timestamp: '14:57', tokenEst: 130,
        content: '用 selector 精确订阅：`useSettings((s) => s.fontSize)`，组件只在自己关心的字段变化时重渲染。面板改完后 `SettingsPanel` 从 203 行降到 96 行，新增选项只需动 slice 和一个表单行。',
      },
      {
        id: 'cu2-m6', role: 'assistant', kind: 'tool', timestamp: '14:58', tokenEst: 18,
        toolName: 'Edit',
        content: '⚙ Edit(src/settings/SettingsPanel.tsx) · −107 lines',
      },
      {
        id: 'cu2-m7', role: 'assistant', kind: 'text', timestamp: '14:59', tokenEst: 52,
        content: '重构完成，persist 中间件顺手把设置持久化到了 localStorage，刷新不丢。',
      },
    ],
  },

  // ============================ Aider ============================
  {
    id: 'sess-aider-1',
    agentId: 'aider',
    title: '批量重命名 REST 路由并更新全部调用方',
    filePath: '~/.aider.chat.history.md · rename-routes',
    cwd: '/home/dev/work/legacy-backend',
    date: '2025-07-26',
    turnCount: 8,
    tokenCount: 11240,
    messages: [
      {
        id: 'a1-m1', role: 'user', kind: 'text', timestamp: '10:33', tokenEst: 70,
        content: '把 `/api/v1/getUserList`、`/api/v1/getOrderDetail` 这类动词式路由全部改成 REST 语义（`/users`、`/orders/:id`），并更新前端所有调用点。',
      },
      {
        id: 'a1-m2', role: 'assistant', kind: 'tool', timestamp: '10:33', tokenEst: 22,
        toolName: 'Bash',
        content: "⚙ Bash(grep -rn 'api/v1' src/ | wc -l) · 47 call sites",
      },
      {
        id: 'a1-m3', role: 'assistant', kind: 'text', timestamp: '10:34', tokenEst: 160,
        content: '映射方案：\n\n- `GET /api/v1/getUserList` → `GET /users`\n- `GET /api/v1/getOrderDetail?id=` → `GET /orders/:id`\n- `POST /api/v1/createOrder` → `POST /orders`\n- `POST /api/v1/updateUser` → `PATCH /users/:id`\n\n共 14 条路由、47 个调用点。先在服务端加新路由并保留旧路由别名，前端迁移完再下旧路由。',
      },
      {
        id: 'a1-m4', role: 'assistant', kind: 'diff', timestamp: '10:35', tokenEst: 310,
        content: "--- a/src/server/routes.ts\n+++ b/src/server/routes.ts\n@@ -12,8 +12,12 @@\n-router.get('/api/v1/getUserList', listUsers);\n+router.get('/users', listUsers);\n+// legacy alias, remove after frontend migration\n+router.get('/api/v1/getUserList', deprecationWarning, listUsers);\n",
      },
      {
        id: 'a1-m5', role: 'assistant', kind: 'tool', timestamp: '10:37', tokenEst: 20,
        toolName: 'Edit',
        content: '⚙ Edit(src/api/client.ts + 31 files) · +94 −88 lines',
      },
      {
        id: 'a1-m6', role: 'user', kind: 'text', timestamp: '10:41', tokenEst: 36,
        content: '全部改完跑一下 e2e，确认没有漏网的旧调用。',
      },
      {
        id: 'a1-m7', role: 'assistant', kind: 'tool', timestamp: '10:42', tokenEst: 24,
        toolName: 'Bash',
        content: '⚙ Bash(pnpm e2e) · 42 passed · 0 legacy calls · 58s',
      },
      {
        id: 'a1-m8', role: 'assistant', kind: 'text', timestamp: '10:43', tokenEst: 66,
        content: 'e2e 全绿，运行时日志里 0 条 legacy 路由命中。旧别名加了 30 天废弃警告头，到期后删掉即可。',
      },
    ],
  },
  {
    id: 'sess-aider-2',
    agentId: 'aider',
    title: '接入 i18n 并提取硬编码中文文案',
    filePath: '~/.aider.chat.history.md · i18n-extract',
    cwd: '~/projects/marketing-site',
    date: '2025-07-19',
    turnCount: 9,
    tokenCount: 13570,
    messages: [
      {
        id: 'a2-m1', role: 'user', kind: 'text', timestamp: '13:02', tokenEst: 66,
        content: '产品要出英文版。把 src 下所有硬编码中文文案提取到 i18n 字典，用 react-i18next。',
      },
      {
        id: 'a2-m2', role: 'assistant', kind: 'tool', timestamp: '13:02', tokenEst: 23,
        toolName: 'Bash',
        content: "⚙ Bash(grep -rnP '[\\x{4e00}-\\x{9fff}]' src/ -l) · 38 files",
      },
      {
        id: 'a2-m3', role: 'assistant', kind: 'text', timestamp: '13:03', tokenEst: 140,
        content: '计划：\n\n1. 初始化 `i18next` + `react-i18next`，字典放 `src/locales/{zh,en}.json`\n2. 用 `i18next-parser` 扫描提取 38 个文件里的硬编码中文，key 用 `驼峰.模块.语义` 命名\n3. 替换为 `t("key")` 调用',
      },
      {
        id: 'a2-m4', role: 'assistant', kind: 'code', timestamp: '13:04', tokenEst: 260,
        language: 'json',
        content: "{\n  \"workspace.emptyPane\": \"拖入会话文件或从库中选择\",\n  \"workspace.copySelected\": \"复制所选片段\",\n  \"library.importHint\": \"支持 .jsonl / .md / .db 格式\",\n  \"composer.copiedToast\": \"已复制 {{count}} 个片段\",\n  \"common.confirm\": \"确认\",\n  \"common.cancel\": \"取消\"\n}",
      },
      {
        id: 'a2-m5', role: 'assistant', kind: 'diff', timestamp: '13:06', tokenEst: 230,
        content: "--- a/src/components/EmptyPane.tsx\n+++ b/src/components/EmptyPane.tsx\n@@ -4,7 +4,7 @@\n-      <p>拖入会话文件或从库中选择</p>\n+      <p>{t('workspace.emptyPane')}</p>\n",
      },
      {
        id: 'a2-m6', role: 'assistant', kind: 'tool', timestamp: '13:09', tokenEst: 21,
        toolName: 'Edit',
        content: '⚙ Edit(38 files) · +412 −356 lines',
      },
      {
        id: 'a2-m7', role: 'user', kind: 'text', timestamp: '13:12', tokenEst: 42,
        content: '英文翻译先给一版机器初稿就行，后面人工校对。',
      },
      {
        id: 'a2-m8', role: 'assistant', kind: 'code', timestamp: '13:13', tokenEst: 220,
        language: 'json',
        content: "{\n  \"workspace.emptyPane\": \"Drop a session file here or pick from the library\",\n  \"workspace.copySelected\": \"Copy selected segments\",\n  \"library.importHint\": \"Supports .jsonl / .md / .db formats\",\n  \"composer.copiedToast\": \"Copied {{count}} segments\",\n  \"common.confirm\": \"Confirm\",\n  \"common.cancel\": \"Cancel\"\n}",
      },
      {
        id: 'a2-m9', role: 'assistant', kind: 'text', timestamp: '13:14', tokenEst: 60,
        content: '完成：共提取 217 条文案，zh/en 字典就绪。构建产物里中文全部来自字典文件，运行时切换语言即时生效。',
      },
    ],
  },
);

// ---------------------------------------------------------------------------
// 导出辅助
// ---------------------------------------------------------------------------

export function getSessionsByAgent(): Record<AgentId, Session[]> {
  const grouped = {} as Record<AgentId, Session[]>;
  for (const agentId of Object.keys(AGENTS) as AgentId[]) {
    grouped[agentId] = mockSessions.filter((s) => s.agentId === agentId);
  }
  return grouped;
}

export function getSessionById(id: string): Session | undefined {
  return mockSessions.find((s) => s.id === id);
}
