import { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router';
import { AnimatePresence, motion } from 'framer-motion';
import {
  DndContext,
  PointerSensor,
  closestCenter,
  useSensor,
  useSensors,
  type DragEndEvent,
} from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import {
  Check,
  ChevronDown,
  ChevronUp,
  ClipboardCopy,
  Clock,
  Download,
  History,
  Layers,
  Link2,
  Merge,
  Trash2,
} from 'lucide-react';
import type { Segment } from '@/lib/types';
import { getSessionById } from '@/data/mockSessions';
import {
  allSelectedSegments,
  useComposerStore,
  type CopyHistoryEntry,
} from '@/lib/store';
import AgentBadge from '@/components/AgentBadge';
import { toast } from '@/components/Toast';
import SegmentCard from '@/components/composer/SegmentCard';
import Preview from '@/components/composer/Preview';
import {
  FORMATS,
  TEMPLATES,
  buildOutput,
  formatLabel,
  formatNumber,
  queueTokens,
  refLabel,
  type FormatId,
  type TemplateId,
} from '@/components/composer/output';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { cn } from '@/lib/utils';

// ---------------------------------------------------------------------------
// 工具函数
// ---------------------------------------------------------------------------

function buildSegment(sessionId: string, messageId: string): Segment | null {
  const session = getSessionById(sessionId);
  const message = session?.messages.find((m) => m.id === messageId);
  if (!session || !message) return null;
  return {
    id: `${sessionId}:${messageId}`,
    sessionId,
    sessionTitle: session.title,
    agentId: session.agentId,
    message,
  };
}

const EXAMPLE_PAIRS: [string, string][] = [
  ['sess-claude-1', 'c1-m3'],
  ['sess-claude-1', 'c1-m6'],
  ['sess-grok-1', 'g1-m2'],
  ['sess-grok-1', 'g1-m3'],
  ['sess-opencode-1', 'o1-m4'],
  ['sess-codex-1', 'c1x-m2'],
];

async function writeClipboard(text: string) {
  try {
    await navigator.clipboard.writeText(text);
  } catch {
    const ta = document.createElement('textarea');
    ta.value = text;
    document.body.appendChild(ta);
    ta.select();
    document.execCommand('copy');
    document.body.removeChild(ta);
  }
}

function nowTime(): string {
  return new Date().toLocaleTimeString('zh-CN', { hour: '2-digit', minute: '2-digit' });
}

/** 相邻同会话分组（保持队列顺序） */
interface Group {
  sessionId: string;
  items: { segment: Segment; index: number }[];
}

function groupQueue(queue: Segment[]): Group[] {
  const groups: Group[] = [];
  queue.forEach((segment, index) => {
    const last = groups[groups.length - 1];
    if (last && last.sessionId === segment.sessionId) last.items.push({ segment, index });
    else groups.push({ sessionId: segment.sessionId, items: [{ segment, index }] });
  });
  return groups;
}

// ---------------------------------------------------------------------------
// 页面
// ---------------------------------------------------------------------------

export default function Composer() {
  const queue = useComposerStore((s) => s.queue);
  const addToQueue = useComposerStore((s) => s.addToQueue);
  const removeFromQueue = useComposerStore((s) => s.removeFromQueue);
  const reorder = useComposerStore((s) => s.reorder);
  const updateContent = useComposerStore((s) => s.updateContent);
  const clearQueue = useComposerStore((s) => s.clearQueue);
  const copiedHistory = useComposerStore((s) => s.copiedHistory);
  const pushHistory = useComposerStore((s) => s.pushHistory);

  const [template, setTemplate] = useState<TemplateId>('raw');
  const [format, setFormat] = useState<FormatId>('markdown');
  const [includeSource, setIncludeSource] = useState(true);
  const [redact, setRedact] = useState(true);
  const [wrap, setWrap] = useState(true);
  const [lineNumbers, setLineNumbers] = useState(false);
  const [checkedIds, setCheckedIds] = useState<Set<string>>(new Set());
  const [refOverrides, setRefOverrides] = useState<Record<string, string>>({});
  const [mergedParts, setMergedParts] = useState<Record<string, Segment[]>>({});
  const [copied, setCopied] = useState(false);
  const [copyPulse, setCopyPulse] = useState(0);
  const [previewText, setPreviewText] = useState('');

  const undoStack = useRef<Segment[][]>([]);
  const historySeq = useRef(1);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }));

  // 从工作台托盘载入（仅队列空时，挂载一次）
  useEffect(() => {
    const state = useComposerStore.getState();
    if (state.queue.length > 0) return;
    const segments = allSelectedSegments();
    if (segments.length > 0) {
      state.addToQueue(segments);
      toast(`已从托盘载入 ${segments.length} 个片段`);
    }
  }, []);

  // 预览防抖 250ms
  useEffect(() => {
    const t = setTimeout(() => {
      setPreviewText(buildOutput(queue, { template, format, includeSource, redact, refOverrides }));
    }, 250);
    return () => clearTimeout(t);
  }, [queue, template, format, includeSource, redact, refOverrides]);

  const tokens = useMemo(() => queueTokens(queue), [queue]);
  const sessionCount = useMemo(() => new Set(queue.map((s) => s.sessionId)).size, [queue]);
  const groups = useMemo(() => groupQueue(queue), [queue]);
  const refOf = (s: Segment) => refOverrides[s.id] ?? refLabel(s);

  // ---- 队列变更（带撤销快照） ----
  const mutate = (next: Segment[]) => {
    undoStack.current.push(queue.map((s) => ({ ...s, message: { ...s.message } })));
    clearQueue();
    addToQueue(next);
  };

  const undo = () => {
    const prev = undoStack.current.pop();
    if (!prev) return;
    clearQueue();
    addToQueue(prev);
    setCheckedIds(new Set());
    toast('已撤销');
  };

  const removeOne = (id: string) => {
    undoStack.current.push(queue.map((s) => ({ ...s, message: { ...s.message } })));
    removeFromQueue(id);
    setCheckedIds((prev) => {
      const next = new Set(prev);
      next.delete(id);
      return next;
    });
  };

  const saveEdit = (id: string, content: string) => {
    undoStack.current.push(queue.map((s) => ({ ...s, message: { ...s.message } })));
    updateContent(id, content);
  };

  /** 合并队列中 index 与 index+1（须同会话） */
  const mergeAt = (index: number) => {
    const a = queue[index];
    const b = queue[index + 1];
    if (!a || !b || a.sessionId !== b.sessionId) return;
    const partsA = mergedParts[a.id] ?? [a];
    const parts = [...partsA, ...(mergedParts[b.id] ?? [b])];
    const merged: Segment = {
      ...a,
      message: {
        ...a.message,
        content: `${a.message.content}\n\n${b.message.content}`,
        tokenEst: a.message.tokenEst + b.message.tokenEst,
      },
    };
    const next = queue.map((s, i) => (i === index ? merged : s)).filter((_, i) => i !== index + 1);
    const mergedRef = `${refOf(a)}+${refOf(b)}`;
    setMergedParts((prev) => {
      const n = { ...prev, [merged.id]: parts };
      delete n[b.id];
      return n;
    });
    setRefOverrides((prev) => {
      const n = { ...prev, [merged.id]: mergedRef };
      delete n[b.id];
      return n;
    });
    setCheckedIds((prev) => {
      const n = new Set(prev);
      n.delete(b.id);
      return n;
    });
    mutate(next);
    toast('已合并片段', `${mergedRef} · ${formatNumber(merged.message.tokenEst)} tok`);
  };

  /** 拆分已合并片段 */
  const splitAt = (id: string) => {
    const parts = mergedParts[id];
    if (!parts || parts.length < 2) return;
    const index = queue.findIndex((s) => s.id === id);
    if (index === -1) return;
    const next = [...queue.slice(0, index), ...parts, ...queue.slice(index + 1)];
    setMergedParts((prev) => {
      const n = { ...prev };
      delete n[id];
      return n;
    });
    setRefOverrides((prev) => {
      const n = { ...prev };
      delete n[id];
      return n;
    });
    mutate(next);
    toast('已拆分片段');
  };

  /** 批量合并选中的片段（按队列顺序并入第一个） */
  const mergeChecked = () => {
    const picked = queue.filter((s) => checkedIds.has(s.id));
    if (picked.length < 2) return;
    const first = picked[0]!;
    const parts = picked.flatMap((s) => mergedParts[s.id] ?? [s]);
    const merged: Segment = {
      ...first,
      message: {
        ...first.message,
        content: picked.map((s) => s.message.content).join('\n\n'),
        tokenEst: picked.reduce((sum, s) => sum + s.message.tokenEst, 0),
      },
    };
    const pickedIds = new Set(picked.slice(1).map((s) => s.id));
    const next = queue.map((s) => (s.id === first.id ? merged : s)).filter((s) => !pickedIds.has(s.id));
    setMergedParts((prev) => {
      const n = { ...prev, [merged.id]: parts };
      for (const id of pickedIds) delete n[id];
      return n;
    });
    setRefOverrides((prev) => {
      const n = { ...prev, [merged.id]: picked.map((s) => refOf(s)).join('+') };
      for (const id of pickedIds) delete n[id];
      return n;
    });
    setCheckedIds(new Set());
    mutate(next);
    toast(`已合并 ${picked.length} 个片段`);
  };

  /** 整组上移 / 下移 / 移除 */
  const moveGroup = (groupIndex: number, dir: -1 | 1) => {
    const gs = groupQueue(queue);
    const target = gs[groupIndex + dir];
    const current = gs[groupIndex];
    if (!target || !current) return;
    const nextGroups = [...gs];
    nextGroups[groupIndex] = target;
    nextGroups[groupIndex + dir] = current;
    mutate(nextGroups.flatMap((g) => g.items.map((it) => it.segment)));
  };

  const removeGroup = (sessionId: string, startIndex: number) => {
    const group = groupQueue(queue).find(
      (g) => g.sessionId === sessionId && g.items[0]?.index === startIndex,
    );
    if (!group) return;
    const ids = new Set(group.items.map((it) => it.segment.id));
    mutate(queue.filter((s) => !ids.has(s.id)));
  };

  const handleClearQueue = () => {
    if (queue.length === 0) return;
    mutate([]);
    setCheckedIds(new Set());
    setMergedParts({});
    setRefOverrides({});
    toast('队列已清空', '⌘Z 可撤销');
  };

  const loadExamples = () => {
    const segments = EXAMPLE_PAIRS.map(([sid, mid]) => buildSegment(sid, mid)).filter(
      (s): s is Segment => Boolean(s),
    );
    mutate(segments);
    setCheckedIds(new Set());
    setMergedParts({});
    setRefOverrides({});
    toast(`已载入 ${segments.length} 段示例片段`);
  };

  // ---- 拖拽排序 ----
  const onDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    if (!over || active.id === over.id) return;
    const ids = queue.map((s) => s.id);
    const from = ids.indexOf(String(active.id));
    const to = ids.indexOf(String(over.id));
    if (from === -1 || to === -1) return;
    undoStack.current.push(queue.map((s) => ({ ...s, message: { ...s.message } })));
    reorder(from, to);
  };

  // ---- 复制 / 下载 / 历史 ----
  const outputFor = (fmt: FormatId) =>
    buildOutput(queue, { template, format: fmt, includeSource, redact, refOverrides });

  const doCopy = async (fmt: FormatId = format) => {
    if (queue.length === 0) return;
    const text = outputFor(fmt);
    await writeClipboard(text);
    setCopied(true);
    setCopyPulse((n) => n + 1);
    setTimeout(() => setCopied(false), 1600);
    toast(`已复制 ${queue.length} 个片段 · ${formatNumber(tokens)} tokens · ${formatLabel(fmt)}`);
    const entry: CopyHistoryEntry = {
      id: `copy-${historySeq.current++}`,
      format: fmt,
      count: queue.length,
      tokens,
      time: nowTime(),
    };
    pushHistory(entry);
  };

  const download = (fmt: FormatId, ext: string) => {
    if (queue.length === 0) return;
    const blob = new Blob([outputFor(fmt)], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `sessiongrid-${queue.length}-segments${ext}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    toast(`已下载 ${ext} 文件`, `${queue.length} 个片段 · ${formatLabel(fmt)}`);
  };

  // 快捷键：⌘C 复制全部 / ⌘Z 撤销
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (!(e.metaKey || e.ctrlKey)) return;
      const target = e.target as HTMLElement | null;
      const typing =
        target && (target.tagName === 'TEXTAREA' || target.tagName === 'INPUT' || target.isContentEditable);
      if (e.key.toLowerCase() === 'c' && !typing && !window.getSelection()?.toString()) {
        e.preventDefault();
        void doCopy();
      }
      if (e.key.toLowerCase() === 'z' && !typing) {
        e.preventDefault();
        undo();
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  });

  // ---------------------------------------------------------------------------
  // 渲染
  // ---------------------------------------------------------------------------
  return (
    <div className="flex h-[calc(100dvh-52px)] flex-col">
      {/* 工具条 48px */}
      <div className="flex h-12 shrink-0 items-center gap-4 border-b border-border-subtle px-4">
        {/* 模板预设芯片组 */}
        <div className="flex items-center gap-1.5 overflow-x-auto">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setTemplate(t.id)}
              className={cn(
                'h-7 shrink-0 rounded-chip border px-3 text-[12px] font-medium transition-colors duration-150',
                template === t.id
                  ? 'border-lime bg-lime font-bold text-canvas'
                  : 'border-border-subtle text-text-secondary hover:border-border-strong hover:text-text-primary',
              )}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Switch 组 */}
        <div className="ml-auto hidden items-center gap-4 md:flex">
          <label className="flex cursor-pointer items-center gap-2 text-[12px] font-medium text-text-secondary">
            包含来源信息
            <button
              type="button"
              role="switch"
              aria-checked={includeSource}
              onClick={() => setIncludeSource((v) => !v)}
              className={cn(
                'relative h-4 w-7 rounded-full transition-colors duration-150',
                includeSource ? 'bg-lime' : 'bg-border-strong',
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 h-3 w-3 rounded-full transition-all duration-150',
                  includeSource ? 'left-3.5 bg-canvas' : 'left-0.5 bg-text-muted',
                )}
              />
            </button>
          </label>
          <label className="flex cursor-pointer items-center gap-2 text-[12px] font-medium text-text-secondary">
            自动脱敏
            <button
              type="button"
              role="switch"
              aria-checked={redact}
              onClick={() => setRedact((v) => !v)}
              className={cn(
                'relative h-4 w-7 rounded-full transition-colors duration-150',
                redact ? 'bg-lime' : 'bg-border-strong',
              )}
            >
              <span
                className={cn(
                  'absolute top-0.5 h-3 w-3 rounded-full transition-all duration-150',
                  redact ? 'left-3.5 bg-canvas' : 'left-0.5 bg-text-muted',
                )}
              />
            </button>
          </label>
        </div>

        {/* 格式 Tabs */}
        <div className="flex items-center rounded-btn border border-border-subtle bg-panel p-0.5">
          {FORMATS.map((f) => {
            const active = format === f.id;
            return (
              <button
                key={f.id}
                type="button"
                onClick={() => setFormat(f.id)}
                className="relative h-7 rounded-[6px] px-3 text-[12px] font-medium transition-colors duration-150"
              >
                {active && (
                  <motion.span
                    layoutId="composer-format-tab"
                    className="absolute inset-0 rounded-[6px] bg-raised ring-1 ring-border-strong"
                    transition={{ type: 'spring', stiffness: 400, damping: 32 }}
                  />
                )}
                <span className={cn('relative', active ? 'text-lime' : 'text-text-muted hover:text-text-secondary')}>
                  {f.label}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* 主体两列 */}
      <div className="grid min-h-0 flex-1 grid-cols-1 lg:grid-cols-[42%_58%]">
        {/* 左列：片段队列 */}
        <div className="flex min-h-0 flex-col border-r border-border-subtle">
          <div className="flex h-11 shrink-0 items-center gap-2 border-b border-border-subtle px-4">
            <Layers className="h-4 w-4 text-text-muted" />
            <h2 className="text-[14px] font-bold">片段队列</h2>
            <span className="font-mono text-[12px] text-lime">{queue.length}</span>
            <div className="ml-auto flex items-center gap-2">
              {checkedIds.size > 0 && (
                <>
                  <button
                    type="button"
                    onClick={mergeChecked}
                    disabled={checkedIds.size < 2}
                    className="flex h-6 items-center gap-1 rounded-chip border border-border-subtle px-2 text-[11px] font-medium text-text-secondary transition-colors hover:border-lime/60 hover:text-lime disabled:opacity-40"
                  >
                    <Merge className="h-3 w-3" />
                    合并 ({checkedIds.size})
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      const next = queue.filter((s) => !checkedIds.has(s.id));
                      mutate(next);
                      setCheckedIds(new Set());
                      toast(`已移除 ${checkedIds.size} 个片段`);
                    }}
                    className="flex h-6 items-center gap-1 rounded-chip border border-border-subtle px-2 text-[11px] font-medium text-text-secondary transition-colors hover:border-danger/60 hover:text-danger"
                  >
                    <Trash2 className="h-3 w-3" />
                    移除 ({checkedIds.size})
                  </button>
                </>
              )}
              <button
                type="button"
                onClick={() =>
                  setCheckedIds(
                    checkedIds.size === queue.length ? new Set() : new Set(queue.map((s) => s.id)),
                  )
                }
                className="h-6 rounded-chip px-2 text-[11px] font-medium text-text-secondary transition-colors hover:text-text-primary"
              >
                {checkedIds.size === queue.length && queue.length > 0 ? '取消全选' : '全选'}
              </button>
              <button
                type="button"
                onClick={handleClearQueue}
                className="h-6 rounded-chip px-2 text-[11px] font-medium text-text-secondary transition-colors hover:text-danger"
              >
                清空
              </button>
            </div>
          </div>

          <div className="min-h-0 flex-1 overflow-y-auto p-4">
            {queue.length === 0 ? (
              <div className="flex h-full flex-col items-center justify-center gap-4 text-center">
                <motion.img
                  src="/composer-illustration.svg"
                  alt=""
                  className="h-36 w-auto opacity-80"
                  animate={{ y: [0, -6, 0] }}
                  transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
                />
                <div>
                  <p className="text-[15px] font-bold text-text-primary">队列是空的</p>
                  <p className="mt-1 font-mono text-[11px] text-text-muted">// 去工作台摘选消息片段</p>
                </div>
                <div className="flex items-center gap-3">
                  <Link
                    to="/workspace"
                    className="flex h-9 items-center gap-1.5 rounded-btn bg-lime px-4 text-[13px] font-bold text-canvas transition-colors hover:brightness-110"
                  >
                    去工作台摘选片段 →
                  </Link>
                  <button
                    type="button"
                    onClick={loadExamples}
                    className="h-9 rounded-btn border border-border-strong px-4 text-[13px] font-medium text-text-primary transition-colors hover:border-lime hover:text-lime"
                  >
                    载入示例片段
                  </button>
                </div>
              </div>
            ) : (
              <DndContext sensors={sensors} collisionDetection={closestCenter} onDragEnd={onDragEnd}>
                <SortableContext items={queue.map((s) => s.id)} strategy={verticalListSortingStrategy}>
                  <div className="flex flex-col gap-4">
                    {groups.map((group, gi) => {
                      const first = group.items[0]!.segment;
                      return (
                        <div key={`${group.sessionId}-${gi}`} className="flex flex-col gap-2">
                          {/* 组头 */}
                          <div className="group/gh flex items-center gap-2 px-1">
                            <AgentBadge agentId={first.agentId} compact />
                            <span className="truncate text-[13px] font-medium text-text-secondary">
                              {first.sessionTitle}
                            </span>
                            <span className="flex items-center gap-0.5 opacity-0 transition-opacity group-hover/gh:opacity-100">
                              <button
                                type="button"
                                title="整组上移"
                                disabled={gi === 0}
                                onClick={() => moveGroup(gi, -1)}
                                className="flex h-5 w-5 items-center justify-center rounded text-text-muted transition-colors hover:text-text-primary disabled:opacity-30"
                              >
                                <ChevronUp className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                title="整组下移"
                                disabled={gi === groups.length - 1}
                                onClick={() => moveGroup(gi, 1)}
                                className="flex h-5 w-5 items-center justify-center rounded text-text-muted transition-colors hover:text-text-primary disabled:opacity-30"
                              >
                                <ChevronDown className="h-3.5 w-3.5" />
                              </button>
                              <button
                                type="button"
                                title="整组移除"
                                onClick={() => removeGroup(group.sessionId, group.items[0]!.index)}
                                className="flex h-5 w-5 items-center justify-center rounded text-text-muted transition-colors hover:text-danger"
                              >
                                <Trash2 className="h-3.5 w-3.5" />
                              </button>
                            </span>
                          </div>

                          {/* 组内片段 */}
                          <div className="flex flex-col gap-2">
                            <AnimatePresence initial={false}>
                              {group.items.map(({ segment }, ii) => (
                                <motion.div
                                  key={segment.id}
                                  layout="position"
                                  initial={{ opacity: 0, y: 12 }}
                                  animate={{ opacity: 1, y: 0 }}
                                  exit={{ opacity: 0, scale: 0.95, transition: { duration: 0.2 } }}
                                  transition={{ type: 'spring', stiffness: 380, damping: 32 }}
                                  className="flex flex-col"
                                >
                                  <SegmentCard
                                    segment={segment}
                                    refText={refOf(segment)}
                                    checked={checkedIds.has(segment.id)}
                                    merged={Boolean(mergedParts[segment.id])}
                                    onCheck={(c) =>
                                      setCheckedIds((prev) => {
                                        const next = new Set(prev);
                                        if (c) next.add(segment.id);
                                        else next.delete(segment.id);
                                        return next;
                                      })
                                    }
                                    onSave={(content) => saveEdit(segment.id, content)}
                                    onRemove={() => removeOne(segment.id)}
                                    onSplit={
                                      mergedParts[segment.id] ? () => splitAt(segment.id) : undefined
                                    }
                                  />
                                  {/* 相邻同会话：合并细条 */}
                                  {ii < group.items.length - 1 && (
                                    <button
                                      type="button"
                                      onClick={() => mergeAt(group.items[ii]!.index)}
                                      className="mx-auto mt-1 flex h-5 items-center gap-1 rounded-chip border border-transparent px-2 font-mono text-[10px] text-text-muted opacity-0 transition-all duration-150 hover:border-border-subtle hover:bg-raised hover:text-lime hover:opacity-100 focus:opacity-100"
                                    >
                                      ⇅ 合并
                                    </button>
                                  )}
                                </motion.div>
                              ))}
                            </AnimatePresence>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </SortableContext>
              </DndContext>
            )}
          </div>
        </div>

        {/* 右列：实时预览 */}
        <div className="min-h-0 p-4">
          <Preview
            text={previewText}
            formatName={formatLabel(format)}
            segmentCount={queue.length}
            tokens={tokens}
            wrap={wrap}
            lineNumbers={lineNumbers}
            onWrapChange={setWrap}
            onLineNumbersChange={setLineNumbers}
            animKey={`${template}-${format}-${queue.length === 0}`}
          />
        </div>
      </div>

      {/* 底栏 56px */}
      <div className="flex h-14 shrink-0 items-center gap-4 border-t border-border-subtle bg-canvas px-4">
        <span className="font-mono text-[12px] text-text-muted">
          <span className="text-text-secondary">{queue.length}</span> 片段 · 来自{' '}
          <span className="text-text-secondary">{sessionCount}</span> 个会话 ·{' '}
          <span className="text-text-secondary">{formatNumber(tokens)}</span> tokens
        </span>

        {/* 复制历史 */}
        <Popover>
          <PopoverTrigger asChild>
            <button
              type="button"
              className="flex h-8 items-center gap-1.5 rounded-btn border border-border-subtle bg-panel px-3 text-[12px] font-medium text-text-secondary transition-colors hover:border-border-strong hover:text-text-primary"
            >
              <History className="h-3.5 w-3.5" />
              复制历史
              {copiedHistory.length > 0 && (
                <span className="font-mono text-[10px] text-lime">{copiedHistory.length}</span>
              )}
            </button>
          </PopoverTrigger>
          <PopoverContent align="start" side="top" className="w-[320px] border-border-subtle bg-raised p-2">
            <p className="px-2 py-1 font-mono text-[11px] text-text-muted">// 最近 10 次复制</p>
            {copiedHistory.length === 0 ? (
              <p className="px-2 py-4 text-center text-[12px] text-text-muted">还没有复制记录</p>
            ) : (
              <div className="flex max-h-[280px] flex-col overflow-y-auto">
                {copiedHistory.slice(0, 10).map((h) => (
                  <div
                    key={h.id}
                    className="flex items-center gap-2 rounded-btn px-2 py-1.5 transition-colors hover:bg-panel"
                  >
                    <Clock className="h-3.5 w-3.5 shrink-0 text-text-muted" />
                    <span className="font-mono text-[11px] text-text-muted">{h.time}</span>
                    <span className="text-[12px] font-medium text-text-primary">
                      {formatLabel(h.format as FormatId)}
                    </span>
                    <span className="font-mono text-[11px] text-text-muted">
                      {h.count} 片段 · {formatNumber(h.tokens)} tok
                    </span>
                    <button
                      type="button"
                      onClick={() => void doCopy(h.format as FormatId)}
                      className="ml-auto rounded-chip border border-border-subtle px-2 py-0.5 text-[11px] font-medium text-text-secondary transition-colors hover:border-lime/60 hover:text-lime"
                    >
                      再次复制
                    </button>
                  </div>
                ))}
              </div>
            )}
          </PopoverContent>
        </Popover>

        <div className="ml-auto flex items-center gap-2.5">
          {/* 下载 */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button
                type="button"
                disabled={queue.length === 0}
                className="flex h-9 items-center gap-1.5 rounded-btn border border-border-strong px-3.5 text-[13px] font-medium text-text-primary transition-colors hover:border-lime hover:text-lime disabled:opacity-40"
              >
                <Download className="h-4 w-4" />
                下载
                <ChevronDown className="h-3.5 w-3.5" />
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" side="top" className="border-border-subtle bg-raised">
              <DropdownMenuItem onClick={() => download('markdown', '.md')}>Markdown（.md）</DropdownMenuItem>
              <DropdownMenuItem onClick={() => download('json', '.json')}>JSON（.json）</DropdownMenuItem>
              <DropdownMenuItem onClick={() => download('text', '.txt')}>纯文本（.txt）</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* 生成分享链接 */}
          <button
            type="button"
            onClick={() => toast('Demo 环境 · 链接仅本地有效')}
            className="flex h-9 items-center gap-1.5 rounded-btn px-3 text-[13px] font-medium text-text-secondary transition-colors hover:bg-raised hover:text-text-primary"
          >
            <Link2 className="h-4 w-4" />
            生成分享链接
          </button>

          {/* 复制到剪贴板（主按钮 + 脉冲反馈） */}
          <motion.button
            type="button"
            onClick={() => void doCopy()}
            disabled={queue.length === 0}
            whileTap={{ scale: 0.97 }}
            className={cn(
              'relative flex h-10 items-center gap-2 rounded-btn px-5 text-[13px] font-bold transition-colors duration-150',
              queue.length === 0 ? 'cursor-not-allowed bg-raised text-text-muted' : 'bg-lime text-canvas hover:brightness-110',
            )}
          >
            {copyPulse > 0 && (
              <motion.span
                key={copyPulse}
                initial={{ opacity: 0.9, scale: 1 }}
                animate={{ opacity: 0, scale: 1.4 }}
                transition={{ duration: 0.6, ease: 'easeOut' }}
                className="pointer-events-none absolute inset-0 rounded-btn border-2 border-lime"
              />
            )}
            {copied ? (
              <>
                <Check className="h-4 w-4" strokeWidth={3} />
                已复制 ✓
              </>
            ) : (
              <>
                <ClipboardCopy className="h-4 w-4" />
                复制为 {formatLabel(format)}
              </>
            )}
          </motion.button>
        </div>
      </div>
    </div>
  );
}
