// SessionGrid shared types

export type AgentId = 'claude' | 'grok' | 'opencode' | 'codex' | 'cursor' | 'aider';

export interface Agent {
  id: AgentId;
  name: string;
  /** Agent 识别色 (design.md §2) */
  color: string;
  /** 缩写: CC / GB / OC / CX / CU / AI */
  abbr: string;
  model: string;
}

export type MessageRole = 'user' | 'assistant';
export type MessageKind = 'text' | 'code' | 'tool' | 'diff';

export interface Message {
  id: string;
  role: MessageRole;
  kind: MessageKind;
  /** Markdown 正文 / 代码 / 工具调用描述 / diff 文本 */
  content: string;
  /** HH:mm 时间戳 */
  timestamp: string;
  /** token 估算 */
  tokenEst: number;
  /** 代码块语言（kind === 'code' 时） */
  language?: string;
  /** 工具名（kind === 'tool' 时，如 Read / Edit / Bash） */
  toolName?: string;
}

export interface Session {
  id: string;
  agentId: AgentId;
  title: string;
  filePath: string;
  /** YYYY-MM-DD */
  date: string;
  turnCount: number;
  tokenCount: number;
  messages: Message[];
}

/** 摘选片段（托盘 / 编排器共用） */
export interface Segment {
  id: string;
  sessionId: string;
  sessionTitle: string;
  agentId: AgentId;
  message: Message;
}

export const AGENTS: Record<AgentId, Agent> = {
  claude: { id: 'claude', name: 'Claude Code', color: '#FF7A59', abbr: 'CC', model: 'claude-opus-4.6' },
  grok: { id: 'grok', name: 'Grok Build', color: '#5B8CFF', abbr: 'GB', model: 'grok-4-heavy' },
  opencode: { id: 'opencode', name: 'OpenCode', color: '#3ECF8E', abbr: 'OC', model: 'gpt-5.2' },
  codex: { id: 'codex', name: 'Codex CLI', color: '#F5A524', abbr: 'CX', model: 'gpt-5.2-codex' },
  cursor: { id: 'cursor', name: 'Cursor', color: '#B18CFF', abbr: 'CU', model: 'composer-1' },
  aider: { id: 'aider', name: 'Aider', color: '#FF5C8A', abbr: 'AI', model: 'deepseek-v3.2' },
};

export const AGENT_LIST: Agent[] = Object.values(AGENTS);
