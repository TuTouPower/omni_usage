import { useEffect, useRef, useState } from 'react';
import { motion } from 'framer-motion';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { AlertTriangle, Check, Copy, GripVertical, Pencil, Scissors, X } from 'lucide-react';
import type { Segment } from '@/lib/types';
import { AGENTS } from '@/lib/types';
import { toast } from '@/components/Toast';
import { formatNumber } from '@/components/composer/output';
import { cn } from '@/lib/utils';

interface SegmentCardProps {
  segment: Segment;
  refText: string;
  checked: boolean;
  merged: boolean;
  onCheck: (checked: boolean) => void;
  onSave: (content: string) => void;
  onRemove: () => void;
  onSplit?: () => void;
}

/**
 * SegmentCard — (composer.md §2)
 * grip 手柄 + 序号徽标（Agent 色描边）+ 3 行预览 + token 估算 + hover 操作。
 */
export default function SegmentCard({
  segment,
  refText,
  checked,
  merged,
  onCheck,
  onSave,
  onRemove,
  onSplit,
}: SegmentCardProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
    id: segment.id,
  });
  const [editing, setEditing] = useState(false);
  const [draft, setDraft] = useState(segment.message.content);
  const taRef = useRef<HTMLTextAreaElement>(null);

  const agent = AGENTS[segment.agentId];
  const tooLong = segment.message.tokenEst > 8000;

  // textarea 自动高度
  useEffect(() => {
    if (editing && taRef.current) {
      const ta = taRef.current;
      ta.style.height = 'auto';
      ta.style.height = `${Math.min(ta.scrollHeight, 320)}px`;
      ta.focus();
    }
  }, [editing]);

  const save = () => {
    onSave(draft.trim() || segment.message.content);
    setEditing(false);
  };

  const copyThis = async (e: React.MouseEvent) => {
    e.stopPropagation();
    try {
      await navigator.clipboard.writeText(segment.message.content);
    } catch {
      const ta = document.createElement('textarea');
      ta.value = segment.message.content;
      document.body.appendChild(ta);
      ta.select();
      document.execCommand('copy');
      document.body.removeChild(ta);
    }
    toast('已复制此片段', `${agent.name} · ${refText}`);
  };

  return (
    <div
      ref={setNodeRef}
      style={{ transform: CSS.Transform.toString(transform), transition }}
      className={cn(
        'group relative flex gap-2.5 rounded-btn border bg-panel p-3 transition-colors duration-150',
        isDragging ? 'z-10 rotate-[1.5deg] border-border-strong shadow-float' : 'border-border-subtle hover:border-border-strong',
        checked && 'border-lime/60 bg-lime-dim/30',
      )}
    >
      {/* 复选框 */}
      <input
        type="checkbox"
        checked={checked}
        onChange={(e) => onCheck(e.target.checked)}
        aria-label="选择片段"
        className="mt-1 h-3.5 w-3.5 shrink-0 cursor-pointer accent-[#C6F63D]"
      />

      {/* grip 拖拽手柄 */}
      <button
        type="button"
        aria-label="拖拽排序"
        {...attributes}
        {...listeners}
        className="mt-0.5 hidden h-6 w-4 shrink-0 cursor-grab items-center justify-center text-text-muted hover:text-text-secondary active:cursor-grabbing group-hover:flex"
      >
        <GripVertical className="h-4 w-4" />
      </button>

      {/* 序号徽标 */}
      <span
        className="flex h-6 w-6 shrink-0 items-center justify-center rounded-[4px] border bg-inset font-mono text-[10px] font-bold"
        style={{ borderColor: agent.color, color: agent.color }}
        title={`${agent.name} · ${segment.sessionTitle}`}
      >
        {refText}
      </span>

      {/* 内容区 */}
      <div className="min-w-0 flex-1">
        {editing ? (
          <div className="flex flex-col gap-2">
            <textarea
              ref={taRef}
              value={draft}
              onChange={(e) => {
                setDraft(e.target.value);
                e.target.style.height = 'auto';
                e.target.style.height = `${Math.min(e.target.scrollHeight, 320)}px`;
              }}
              onKeyDown={(e) => {
                if (e.key === 'Escape') setEditing(false);
                if ((e.metaKey || e.ctrlKey) && e.key === 'Enter') save();
              }}
              className="w-full resize-none overflow-y-auto rounded-btn border border-border-strong bg-inset p-2 text-[13px] leading-relaxed text-text-primary outline-none focus:border-lime/60"
            />
            <div className="flex gap-2">
              <button
                type="button"
                onClick={save}
                className="flex h-6 items-center gap-1 rounded-chip bg-lime px-2.5 text-[11px] font-bold text-canvas hover:brightness-110"
              >
                <Check className="h-3 w-3" />
                保存
              </button>
              <button
                type="button"
                onClick={() => {
                  setDraft(segment.message.content);
                  setEditing(false);
                }}
                className="h-6 rounded-chip border border-border-subtle px-2.5 text-[11px] font-medium text-text-secondary hover:border-border-strong hover:text-text-primary"
              >
                取消
              </button>
            </div>
          </div>
        ) : (
          <>
            {segment.message.kind === 'code' || segment.message.kind === 'diff' ? (
              <pre className="line-clamp-3 whitespace-pre-wrap rounded-[6px] border border-border-subtle bg-inset px-2 py-1.5 font-mono text-[11px] leading-relaxed text-text-secondary">
                {segment.message.content}
              </pre>
            ) : (
              <p className="line-clamp-3 whitespace-pre-wrap text-[13px] leading-relaxed text-text-secondary">
                {segment.message.content}
              </p>
            )}
            <div className="mt-1.5 flex items-center gap-2">
              <span className="font-mono text-[11px] text-text-muted">
                {formatNumber(segment.message.tokenEst)} tok
              </span>
              {merged && (
                <span className="rounded-chip border border-border-strong px-1.5 py-px font-mono text-[10px] text-text-secondary">
                  已合并
                </span>
              )}
              {tooLong && (
                <motion.span
                  initial={{ opacity: 0, rotate: -2 }}
                  animate={{ opacity: 1, rotate: [0, 2, -2, 0] }}
                  transition={{ duration: 0.4, repeat: 1 }}
                  className="flex items-center gap-1 rounded-chip border border-agent-codex/60 px-1.5 py-px text-[10px] font-medium text-agent-codex"
                >
                  <AlertTriangle className="h-3 w-3" />
                  超长
                </motion.span>
              )}
            </div>
          </>
        )}
      </div>

      {/* hover 操作 */}
      {!editing && (
        <div className="flex shrink-0 flex-col gap-1 opacity-0 transition-opacity duration-150 group-hover:opacity-100">
          <button
            type="button"
            title="编辑"
            onClick={() => {
              setDraft(segment.message.content);
              setEditing(true);
            }}
            className="flex h-6 w-6 items-center justify-center rounded-chip border border-border-subtle bg-raised text-text-muted transition-colors hover:border-border-strong hover:text-text-primary"
          >
            <Pencil className="h-3.5 w-3.5" />
          </button>
          <button
            type="button"
            title="复制此条"
            onClick={copyThis}
            className="flex h-6 w-6 items-center justify-center rounded-chip border border-border-subtle bg-raised text-text-muted transition-colors hover:border-border-strong hover:text-text-primary"
          >
            <Copy className="h-3.5 w-3.5" />
          </button>
          {merged && onSplit && (
            <button
              type="button"
              title="拆分"
              onClick={onSplit}
              className="flex h-6 w-6 items-center justify-center rounded-chip border border-border-subtle bg-raised text-text-muted transition-colors hover:border-border-strong hover:text-text-primary"
            >
              <Scissors className="h-3.5 w-3.5" />
            </button>
          )}
          <button
            type="button"
            title="移除"
            onClick={onRemove}
            className="flex h-6 w-6 items-center justify-center rounded-chip border border-border-subtle bg-raised text-text-muted transition-colors hover:border-danger/60 hover:text-danger"
          >
            <X className="h-3.5 w-3.5" />
          </button>
        </div>
      )}
    </div>
  );
}
