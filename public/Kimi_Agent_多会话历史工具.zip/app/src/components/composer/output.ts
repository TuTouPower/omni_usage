import type { Segment } from '@/lib/types';
import { AGENTS } from '@/lib/types';
import { getSessionById } from '@/data/mockSessions';

// ---------------------------------------------------------------------------
// 模板与格式定义
// ---------------------------------------------------------------------------

export type TemplateId = 'raw' | 'review' | 'bug' | 'ctx' | 'compare';
export type FormatId = 'markdown' | 'json' | 'text' | 'prompt';

export const TEMPLATES: { id: TemplateId; label: string }[] = [
  { id: 'raw', label: '原始拼接' },
  { id: 'review', label: '代码审查' },
  { id: 'bug', label: 'Bug 报告' },
  { id: 'ctx', label: '上下文打包' },
  { id: 'compare', label: '对比分析' },
];

export const FORMATS: { id: FormatId; label: string; ext: string }[] = [
  { id: 'markdown', label: 'Markdown', ext: '.md' },
  { id: 'json', label: 'JSON', ext: '.json' },
  { id: 'text', label: '纯文本', ext: '.txt' },
  { id: 'prompt', label: 'Prompt', ext: '.md' },
];

export function formatLabel(id: FormatId): string {
  return FORMATS.find((f) => f.id === id)?.label ?? id;
}

// ---------------------------------------------------------------------------
// 片段序号徽标：U3 / A5（按会话内同角色消息序号）
// ---------------------------------------------------------------------------

export function refLabel(segment: Segment): string {
  const session = getSessionById(segment.sessionId);
  if (!session) return segment.message.role === 'user' ? 'U?' : 'A?';
  const sameRole = session.messages.filter((m) => m.role === segment.message.role);
  const idx = sameRole.findIndex((m) => m.id === segment.message.id);
  return `${segment.message.role === 'user' ? 'U' : 'A'}${idx + 1}`;
}

// ---------------------------------------------------------------------------
// 自动脱敏
// ---------------------------------------------------------------------------

/** 命中标记，用于预览高亮（amber 下划线） */
export const REDACT_MARK_RE = /(<path>|<redacted>)/g;

export function redactText(text: string): string {
  return text
    .replace(/(?:[A-Za-z0-9_.@+~-]+\/)+[A-Za-z0-9_.@+~-]+/g, '<path>') // 文件路径
    .replace(/\b(?:[\w-]+\\){2,}[\w.-]+\b/g, '<path>') // Windows 路径
    .replace(/\b(?:sk|pk|ghp|gho|xox[bap])-[A-Za-z0-9_-]{8,}\b/g, '<redacted>') // 常见密钥前缀
    .replace(/\b[A-Za-z0-9_-]{32,}\b/g, '<redacted>'); // 超长 token 串
}

// ---------------------------------------------------------------------------
// 内容包装：代码 / diff 片段按格式包裹
// ---------------------------------------------------------------------------

function bodyOf(segment: Segment, format: FormatId): string {
  const { kind, content, language } = segment.message;
  if (format === 'markdown' && kind === 'code') {
    return `\`\`\`${language ?? ''}\n${content}\n\`\`\``;
  }
  if (format === 'markdown' && kind === 'diff') {
    return `\`\`\`diff\n${content}\n\`\`\``;
  }
  return content;
}

function sourceLine(segment: Segment, ref: string): string {
  const agent = AGENTS[segment.agentId];
  return `> 来源 ${agent.name} · ${segment.sessionTitle} · ${ref}`;
}

// ---------------------------------------------------------------------------
// 主构建函数
// ---------------------------------------------------------------------------

export interface BuildOptions {
  template: TemplateId;
  format: FormatId;
  includeSource: boolean;
  redact: boolean;
  /** 合并片段的 ref 覆盖（A4+A5） */
  refOverrides?: Record<string, string>;
}

export function buildOutput(segments: Segment[], opts: BuildOptions): string {
  const { template, format, includeSource, redact } = opts;
  const refOf = (s: Segment) => opts.refOverrides?.[s.id] ?? refLabel(s);
  const clean = (t: string) => (redact ? redactText(t) : t);
  const body = (s: Segment) => clean(bodyOf(s, format));

  if (format === 'json') {
    const payload: Record<string, unknown> = {
      template,
      generated_at: new Date().toISOString(),
      segment_count: segments.length,
      total_tokens: segments.reduce((sum, s) => sum + s.message.tokenEst, 0),
      segments: segments.map((s) => ({
        agent: AGENTS[s.agentId].name,
        agent_id: s.agentId,
        session: s.sessionTitle,
        ref: refOf(s),
        role: s.message.role,
        kind: s.message.kind,
        tokens: s.message.tokenEst,
        timestamp: s.message.timestamp,
        content: clean(s.message.content),
      })),
    };
    if (template === 'review') payload.instruction = '请审查以下变更：';
    if (template === 'bug') payload.instruction = '请根据以下记录整理一份 Bug 报告。';
    return JSON.stringify(payload, null, 2);
  }

  // 模板指令头
  const instruction =
    template === 'review'
      ? '请审查以下变更：\n\n'
      : template === 'bug'
        ? '请根据以下会话记录整理一份 Bug 报告（现象 / 根因 / 修复 / 回归建议）：\n\n'
        : template === 'ctx'
          ? '以下是从多个 Coding Agent 会话中摘选的上下文片段：\n\n'
          : '';

  // 对比分析：按会话分节
  if (template === 'compare' && format !== 'prompt') {
    const bySession = new Map<string, Segment[]>();
    for (const s of segments) {
      const arr = bySession.get(s.sessionId) ?? [];
      arr.push(s);
      bySession.set(s.sessionId, arr);
    }
    const labels = 'ABCDEF'.split('');
    const sections = [...bySession.entries()].map(([, segs], i) => {
      const agent = AGENTS[segs[0]!.agentId];
      const heading =
        format === 'text'
          ? `── 方案 ${labels[i] ?? i + 1}（${agent.name} · ${segs[0]!.sessionTitle}） ──`
          : `## 方案 ${labels[i] ?? i + 1}（${agent.name}）`;
      const parts = segs.map((s) => {
        const head = includeSource
          ? format === 'text'
            ? `── ${s.agentId} · ${s.sessionTitle} · ${refOf(s)} ──\n`
            : `${sourceLine(s, refOf(s))}\n\n`
          : '';
        return `${head}${body(s)}`;
      });
      return `${heading}\n\n${parts.join(format === 'text' ? '\n\n' : '\n\n---\n\n')}`;
    });
    const joined = sections.join('\n\n');
    return format === 'text' ? `${instruction}${joined}\n` : `${instruction}${joined}\n`;
  }

  if (format === 'prompt') {
    const inner = segments
      .map((s) => {
        const agent = AGENTS[s.agentId];
        const source = includeSource ? ` session="${s.sessionTitle}"` : '';
        return `  <segment source="${agent.id === 'claude' ? 'claude-code' : agent.name.toLowerCase().replace(/\s+/g, '-')}" ref="${refOf(s)}"${source}>\n${body(s)}\n  </segment>`;
      })
      .join('\n');
    const instr = instruction.trim()
      ? `<instruction>\n${instruction.trim()}\n</instruction>\n\n`
      : '';
    return `${instr}<context>\n${inner}\n</context>\n`;
  }

  // markdown / text 默认拼接
  const sep = format === 'text' ? '\n\n' : '\n\n---\n\n';
  const parts = segments.map((s) => {
    const head = includeSource
      ? format === 'text'
        ? `── ${s.agentId} · ${s.sessionTitle} · ${refOf(s)} ──\n`
        : `${sourceLine(s, refOf(s))}\n\n`
      : '';
    return `${head}${body(s)}`;
  });
  const joined = parts.join(sep);
  if (format === 'text') return `${instruction}${joined}\n`;
  if (template === 'ctx') return `# 上下文打包\n\n${joined}\n`;
  return `${instruction}${joined}\n`;
}

// ---------------------------------------------------------------------------
// 统计
// ---------------------------------------------------------------------------

export function queueTokens(segments: Segment[]): number {
  return segments.reduce((sum, s) => sum + s.message.tokenEst, 0);
}

export function formatNumber(n: number): string {
  return n.toLocaleString('en-US');
}
