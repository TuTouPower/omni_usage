import { Fragment } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { REDACT_MARK_RE, formatNumber } from '@/components/composer/output';
import { cn } from '@/lib/utils';

interface PreviewProps {
  text: string;
  formatName: string;
  segmentCount: number;
  tokens: number;
  wrap: boolean;
  lineNumbers: boolean;
  onWrapChange: (v: boolean) => void;
  onLineNumbersChange: (v: boolean) => void;
  /** 模板/格式切换时重新触发入场动画 */
  animKey: string;
}

/** 迷你 Switch（预览栏用） */
function MiniSwitch({ label, checked, onChange }: { label: string; checked: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className="flex items-center gap-1.5 text-[11px] font-medium text-text-muted transition-colors hover:text-text-secondary"
    >
      {label}
      <span
        className={cn(
          'relative h-3.5 w-6 rounded-full transition-colors duration-150',
          checked ? 'bg-lime' : 'bg-border-strong',
        )}
      >
        <span
          className={cn(
            'absolute top-0.5 h-2.5 w-2.5 rounded-full bg-canvas transition-all duration-150',
            checked ? 'left-3' : 'left-0.5 bg-text-muted',
          )}
        />
      </span>
    </button>
  );
}

/** 单行内容渲染：脱敏命中处 amber 下划线 */
function LineContent({ line }: { line: string }) {
  const parts = line.split(REDACT_MARK_RE);
  return (
    <>
      {parts.map((p, i) =>
        p === '<path>' || p === '<redacted>' ? (
          <motion.span
            key={i}
            title="已脱敏"
            className="text-agent-codex underline decoration-agent-codex/70 underline-offset-2"
            initial={{ backgroundSize: '0% 100%' }}
            animate={{ backgroundSize: '100% 100%' }}
            style={{
              backgroundImage: 'linear-gradient(rgba(245,165,36,0.15), rgba(245,165,36,0.15))',
              backgroundRepeat: 'no-repeat',
            }}
            transition={{ duration: 0.3 }}
          >
            {p}
          </motion.span>
        ) : (
          <Fragment key={i}>{p}</Fragment>
        ),
      )}
    </>
  );
}

/**
 * Preview — (composer.md §3)
 * bg-inset 预览面板：格式名 + mono 统计 + 换行/行号 Switch；内容随模板/格式实时渲染。
 */
export default function Preview({
  text,
  formatName,
  segmentCount,
  tokens,
  wrap,
  lineNumbers,
  onWrapChange,
  onLineNumbersChange,
  animKey,
}: PreviewProps) {
  const chars = text.length;
  const lines = text.split('\n');

  return (
    <div className="flex h-full flex-col overflow-hidden rounded-panel border border-border-subtle bg-inset">
      {/* 顶部小栏 */}
      <div className="flex h-10 shrink-0 items-center gap-3 border-b border-border-subtle px-4">
        <span className="rounded-chip border border-border-strong px-2 py-0.5 text-[11px] font-bold text-text-primary">
          {formatName}
        </span>
        <span className="font-mono text-[11px] text-text-muted">
          {segmentCount} 片段 · {formatNumber(tokens)} tokens · {formatNumber(chars)} 字符
        </span>
        <div className="ml-auto flex items-center gap-4">
          <MiniSwitch label="换行" checked={wrap} onChange={onWrapChange} />
          <MiniSwitch label="行号" checked={lineNumbers} onChange={onLineNumbersChange} />
        </div>
      </div>

      {/* 内容区 */}
      <div className="min-h-0 flex-1 overflow-auto">
        {segmentCount === 0 ? (
          <div className="flex h-full items-center justify-center">
            <p className="font-mono text-[12px] text-text-muted">// nothing to preview</p>
          </div>
        ) : (
          <AnimatePresence mode="wait">
            <motion.div
              key={animKey}
              initial={{ y: 8, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              exit={{ y: -8, opacity: 0 }}
              transition={{ duration: 0.2, ease: [0.22, 1, 0.36, 1] }}
              className="p-4"
            >
              {lineNumbers ? (
                <div className="font-mono text-[12px] leading-[1.65]">
                  {lines.map((line, i) => (
                    <div key={i} className={cn('flex', wrap ? 'whitespace-pre-wrap' : 'whitespace-pre')}>
                      <span className="w-9 shrink-0 select-none pr-3 text-right text-text-muted/50">{i + 1}</span>
                      <span className="min-w-0 flex-1 text-text-secondary">
                        <LineContent line={line} />
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <pre
                  className={cn(
                    'font-mono text-[12px] leading-[1.65] text-text-secondary',
                    wrap ? 'whitespace-pre-wrap break-words' : 'whitespace-pre',
                  )}
                >
                  {text.split(REDACT_MARK_RE).map((p, i) =>
                    p === '<path>' || p === '<redacted>' ? (
                      <span
                        key={i}
                        title="已脱敏"
                        className="text-agent-codex underline decoration-agent-codex/70 underline-offset-2"
                      >
                        {p}
                      </span>
                    ) : (
                      <Fragment key={i}>{p}</Fragment>
                    ),
                  )}
                </pre>
              )}
            </motion.div>
          </AnimatePresence>
        )}
      </div>
    </div>
  );
}
